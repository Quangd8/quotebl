exports = module.exports = function(requireSession, app, controllers, modules) {
  /**
 * @swagger
 * /user/facebook:
 *   post:
 *     description: Share layout
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: name
 *         description: Layout name
 *         in: formData
 *         required: true
 *         type: string
 *     parameters:
 *       - name: layout
 *         description: Layout serialized text data
 *         in: formData
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: Share new layout
 */
  app.post('/layout/share', controllers.layout.share);
}
