'use strict';

var json = require('./json');

exports = module.exports = {
  json: json
};
